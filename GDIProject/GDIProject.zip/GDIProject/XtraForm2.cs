﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace GDIProject
{
    public partial class XtraForm2 : DevExpress.XtraEditors.XtraForm
    {
        public XtraForm2()
        {
            InitializeComponent();
        }

        private void XtraForm2_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillRectangle(Brushes.White, this.ClientRectangle);

            String s = "Accrington Stanley";
            StringFormat sf = new StringFormat(StringFormatFlags.DirectionVertical);
            Font f = new Font("Times New Roman", 14);

            SizeF sizef = g.MeasureString(s, f, Int32.MaxValue, sf);

            RectangleF rf = new RectangleF(40, 50, sizef.Width, sizef.Height);
            g.DrawRectangle(Pens.Black, rf.Left, rf.Top, rf.Width, rf.Height);
            g.DrawString(s, f, Brushes.Black, rf, sf);

            f.Dispose();
        }
    }
}